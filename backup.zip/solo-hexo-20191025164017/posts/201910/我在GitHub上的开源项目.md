title: 我在 GitHub 上的开源项目
date: '2019-10-13 16:30:16'
updated: '2019-10-13 16:30:16'
tags: [开源, GitHub]
permalink: /my-github-repos
---
<!-- 该页面会被定时任务自动覆盖，所以请勿手工更新 -->
<!-- 如果你有更漂亮的排版方式，请发 issue 告诉我们 -->

### 1. [qrcode](https://github.com/youngphp/qrcode) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/youngphp/qrcode/watchers "关注数")&nbsp;&nbsp;[⭐️`3`](https://github.com/youngphp/qrcode/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/youngphp/qrcode/network/members "分叉数")</span>

引用qrcode.js生成二维码并提供下载功能（使用简单，功能强大，不用写任何样式，一键引入js文件即可）



---

### 2. [qrcode-text](https://github.com/youngphp/qrcode-text) <kbd title="主要编程语言">JavaScript</kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/youngphp/qrcode-text/watchers "关注数")&nbsp;&nbsp;[⭐️`2`](https://github.com/youngphp/qrcode-text/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/youngphp/qrcode-text/network/members "分叉数")</span>

js一键生成带文字的二维码



---

### 3. [solo-blog](https://github.com/youngphp/solo-blog) <kbd title="主要编程语言"></kbd> <span style="font-size: 12px;">[🤩`1`](https://github.com/youngphp/solo-blog/watchers "关注数")&nbsp;&nbsp;[⭐️`0`](https://github.com/youngphp/solo-blog/stargazers "收藏数")&nbsp;&nbsp;[🖖`0`](https://github.com/youngphp/solo-blog/network/members "分叉数")&nbsp;&nbsp;[🏠`https://www.shiyunfei.com`](https://www.shiyunfei.com "项目主页")</span>

youngphp 的个人博客 - 记录精彩的程序人生

