title: 关于php使用基于socket Web消息推送系统（workerman）
date: '2019-10-12 18:25:03'
updated: '2019-10-12 18:25:03'
tags: [socket, workerman, 长连接]
permalink: /articles/2019/10/12/1570875903489.html
---
最近公司使用到websocket异步通知客户端做相应的操作，接触到了websocket，在这里分享一些心得！  
我使用的工具是基于wokman的web-msg-sender是一款web长连接推送框架，采用PHPSocket.IO开发，基于WebSocket长连接通讯，如果浏览器不支持WebSocket则自动转用comet推送。 通过后台推送消息，消息可以即时推送到客户端，非轮询，实时性非常好，性能很高。  
下载和demo地址[http://www.workerman.net/web-sender](http://www.workerman.net/web-sender)  
这里面区分服务端和客户端，去上面地址下载源代码，放到你服务端。使用相关命令开启服务。  
其中有一个文件是**start_io.php**，这个文件算是核心，里面有怎么发送socket消息的代码，也会有监控用户上下线的接口，在这个地方可以根据业务需要拓展自己的代码需求。类似：  
用户在socket检测用户上下线的是时候 可以http请求到自己的api层下面我贴一下我的代码  
![自己业务需要知道用户上下线更新用户状态](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTYwOTA1MTYwMTQ2Mzk4?x-oss-process=image/format,png)  
当然了 可能会有童鞋问了，socket如果监听到自己的api发送消息呢。这个时候我们可以看到**start_io.php**这个文件这个地方![监听http端口](https://imgconvert.csdnimg.cn/aHR0cDovL2ltZy5ibG9nLmNzZG4ubmV0LzIwMTYwOTA1MTYxMzA0OTMy?x-oss-process=image/format,png)  
这个地方明确表明了监听端口，websocket跟api在同一个服务器上面，所以用了0.0.0.0，所以你在http服务端如果想发消息给客户端，只需要发送到这个端口上面，socket自动会监听到发送给客户端。
